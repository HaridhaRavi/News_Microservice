package com.haridha.NewsAppRestService.Controller;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.haridha.NewsAppRestService.Model.News;
import com.haridha.NewsAppRestService.Model.NewsAppRestModel;
import com.haridha.NewsAppRestService.Model.Users;

@RequestMapping("/newsApp")
public class NewsRestController {
	
	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}

	@Autowired
	private RestTemplate restTemplate;

	@GetMapping("/news/{userId}")
	public List<NewsAppRestModel> getNewsApp(@PathVariable("userid") String userid) {

		List<Users> users = Arrays.asList(new Users(1, "haridha","123","admin"),new Users(2, "Raj","456", "reader"),
				new Users(3, "ravi","789", "publisher"));

		return users.stream().map(user -> {
			News news = restTemplate.getForObject("http://localhost:8089/newsApp/news/" + user.getUserId(), News.class);
			return new NewsAppRestModel(news.getNewsId(), news.getTitle(),
					news.getText(),user.getUserName(),user.getRole());

		}).collect(Collectors.toList());

	}
	

}
