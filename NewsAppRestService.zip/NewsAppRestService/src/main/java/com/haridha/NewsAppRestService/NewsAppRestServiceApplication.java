package com.haridha.NewsAppRestService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewsAppRestServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewsAppRestServiceApplication.class, args);
	}

}
