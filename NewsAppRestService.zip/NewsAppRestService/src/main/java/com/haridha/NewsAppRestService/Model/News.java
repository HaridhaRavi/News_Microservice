package com.haridha.NewsAppRestService.Model;


import java.time.LocalDateTime;
import java.util.*;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class News {
	
	private int newsId;
	
	private String title;
	
	private String text;

	private String creationDate;

	private String validFrom;

	private String validTo;

	private String role;
}
