package com.haridha.NewsAppRestService.Model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NewsAppRestModel {
	

	private int newsId;
	
	private String title;
	
	private String text;
	
	private String userName;
	
	private String role;
	
	

}
