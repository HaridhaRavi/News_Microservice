package com.haridha.NewsAppRestService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsAppRestServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
