package com.haridha.NewsAppCreation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsAppCreationApplicationTests {

	@Test
	void contextLoads() {
	}

}
