package com.haridha.NewsAppCreation.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.stereotype.Repository;

import com.haridha.NewsAppCreation.Model.News;

@RepositoryRestResource(collectionResourceRel = "news",path ="news")
public interface NewsRepository extends JpaRepository<News, Integer> {

	News findByTitle(String title);
	
}