package com.haridha.NewsAppCreation.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.haridha.NewsAppCreation.Model.News;
import com.haridha.NewsAppCreation.Repository.NewsRepository;

@Service
public class NewsService {
	
	@Autowired
	private NewsRepository newsRepository;
	
	
	public List<News> findAllNews() {
		return newsRepository.findAll();
	}


	public Optional<News> findNewsById(int id) {
		return newsRepository.findById(id);
	}
	
	public News findByTitle(String title) {
		
		News news=newsRepository.findByTitle(title);
		
		return news;
		
	}
	
	public News saveNews(News newNews) {
		
		News news=newsRepository.save(newNews);
		return news;
		
	}

	public News updateNews(int id,News news) {
		
		Optional<News> retrievedNews=newsRepository.findById(id);
		
		if(retrievedNews==null)
			try {
				throw new Exception("News not found");
			} catch (Exception e) {
				e.printStackTrace();
			}
		newsRepository.save(news);
		return newsRepository.findById(id).get();
		
	}
	
	public News deleteNews(int newsId) {
		
		Optional<News> retrievedNews=newsRepository.findById(newsId);
		if(retrievedNews==null)
			try {
				throw new Exception("News not found");
			} catch (Exception e) {
				e.printStackTrace();
			}
		newsRepository.deleteById(newsId);
		return retrievedNews.get();
		
		
		
	}

}