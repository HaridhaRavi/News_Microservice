package com.haridha.NewsAppCreation.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.haridha.NewsAppCreation.Model.UserDetailsImplementation;
import com.haridha.NewsAppCreation.Model.Users;
import com.haridha.NewsAppCreation.Repository.UsersRepository;

@Service
public class UserAuthService implements UserDetailsService{
	
	@Autowired
	private UsersRepository usersRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Users user = usersRepository.findByUserName(username);
		if(user == null) {
			throw new UsernameNotFoundException("User Not Found");
		}
		return new UserDetailsImplementation(user);
	}
	
}
