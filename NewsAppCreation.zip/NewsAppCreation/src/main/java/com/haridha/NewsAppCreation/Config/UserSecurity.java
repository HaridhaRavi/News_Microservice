package com.haridha.NewsAppCreation.Config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import com.haridha.NewsAppCreation.Repository.UsersRepository;

@Component("userSecurity")
public class UserSecurity {
	
	@Autowired
	UsersRepository usersRepository;
	
	public boolean hasUserId(Authentication authentication, Integer userId) {
		
		int userID=usersRepository.findByUserName(authentication.getName()).getUserId();
//		System.out.println(userId+"  "+userID);
            if(userID==userId)
            	return true;
            
            return false;
       
    }

}