package com.haridha.NewsAppCreation.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RestController;

import com.haridha.NewsAppCreation.Model.Users;

@RepositoryRestResource(collectionResourceRel = "users",path ="users")
public interface UsersRepository extends JpaRepository<Users, Integer> {
	
	@RestResource
	Users findByUserName(String userName);
	
	@RestResource
	Users findByUserId(@Param("user_id") int  userId);
}
