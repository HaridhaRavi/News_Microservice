package com.haridha.NewsAppCreation.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.haridha.NewsAppCreation.Model.News;
import com.haridha.NewsAppCreation.Services.NewsService;

@RestController
@RequestMapping("/newsApp")
public class NewsController {
	
	@Autowired
	private NewsService newsService;
	

	@GetMapping("/news")
	public ResponseEntity<List<News>> getAllNews(){
		return ResponseEntity.ok().body(newsService.findAllNews());
	}
	
	@GetMapping("/news/{newsId}")
	public ResponseEntity<News> getNewsById(@PathVariable("newsId") int newsid){
		return ResponseEntity.ok().body(newsService.findNewsById(newsid).get());
	}
	
	@PostMapping("/news")
	public ResponseEntity<News> saveNews(@RequestBody News news,Authentication auth) {
		System.out.println(news.getTitle()+"  "+auth.getName());
		return ResponseEntity.status(HttpStatus.CREATED).body((newsService.saveNews(news)));
		
	}
	
	
	@PutMapping("/news/{newsId}")
	public ResponseEntity<News> updateNews(@PathVariable("newsId") int newsid,@RequestBody News news) {
		return ResponseEntity.ok().body(newsService.updateNews(newsid,news));
		
	}
	
	@DeleteMapping("/news/{newsId}")
	public ResponseEntity<Object> deleteNews(@PathVariable("newsId") int newsid) {
		 newsService.deleteNews(newsid);
		 return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		
	}
	
	@GetMapping("/news/search")
	public ResponseEntity<?> userDetails(Authentication auth, @RequestParam("title") String title) {
		System.out.println(auth.getName().toString());
		News news=newsService.findByTitle(title);
		if(news==null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("News not found");
		}
		return ResponseEntity.ok().body(news);
		
	}
	
	
	

}
